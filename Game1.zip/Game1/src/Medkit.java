import java.util.Random;

public class Medkit {
    private final int x, y;

    private String image = "\uD83D\uDC8A";

    private int heal = 1;

    Medkit(int sizeBoard) {
        Random random = new Random();

        x = 1 + random.nextInt(sizeBoard);
        y = 1 + random.nextInt(sizeBoard - 1);
    }

    public int getX() {
        return x;
    }

    public int getY() {
        return y;
    }

    public String getImage() {
        return image;
    }

    public int getHeal() {
        return heal;
    }

    public boolean conflictPerson(int personX, int personY) {
        return personX == x && personY == y;
    }
}
